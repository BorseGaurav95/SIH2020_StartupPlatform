# firebase-cloud-messaging-web-js
Sample project on Firebase Cloud Messaging for Web using JavaScript

### Run Application
```
git clone https://github.com/mdrkb/firebase-cloud-messaging-web-js.git
cd firebase-cloud-messaging-web-js
```
Launch python server.
```
python -m SimpleHTTPServer 8000
```
Open ```http://localhost:8000``` in the browser and run the curl commands.
