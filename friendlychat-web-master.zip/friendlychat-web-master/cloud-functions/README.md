# Firebase SDK for Cloud Functions Codelab - Final code

This folder contains the final code of the [Firebase SDK for Cloud Functions
](https://codelabs.developers.google.com/codelabs/firebase-cloud-functions/).

You can use this app directly if you'd like to see the finished app but before you do follow the "Create a Firebase Project and Setup" step of the [Codelab instructions](https://codelabs.developers.google.com/codelabs/firebase-cloud-functions/)

If you'd like to follow the step by step codelab start with the [cloud-functions-start](../cloud-functions-start) directory.
